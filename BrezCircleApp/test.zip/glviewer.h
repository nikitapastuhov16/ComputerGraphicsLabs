#ifndef GLVIEWER_H
#define GLVIEWER_H

#include <vector>
#include <QGLWidget>



struct GLViewer : public QGLWidget
{
public:
    GLViewer();
    void initializeGL() override;
    void resizeGL(int w, int h) override;
    void paintGL() override;
    void addPoint(int x, int y);
    QPoint getPoint(int index);
    void random();
private:
    QVector<QPoint> vertices;
};

#endif // GLVIEWER_H
