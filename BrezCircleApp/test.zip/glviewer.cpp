#include "glviewer.h"



GLViewer::GLViewer()
{

}

void GLViewer::initializeGL()
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 600, 0,0,1);
    vertices.push_back(QPoint(10,10));
    vertices.push_back(QPoint(10,300));
    vertices.push_back(QPoint(300,300));
    vertices.push_back(QPoint(300,10));
}
void GLViewer::resizeGL(int w, int h)
{
    glViewport(0,0, w, h);
}
void GLViewer::paintGL()
{
    qglClearColor(Qt::magenta);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPointSize(5);
    glBegin(GL_POINTS);
    glColor3i(100, 255, 50);
    for(int i = 0; i < vertices.size(); ++i) glVertex2i(vertices[i].x(), vertices[i].y());
    glEnd();
    this->update();
}
void GLViewer::addPoint(int x, int y)
{
    vertices.push_back(QPoint(x,y));
    this->paintGL();
}
QPoint GLViewer::getPoint(int index)
{
    return vertices[index];
}
void GLViewer::random()
{
    srand(time(NULL));
    int x = rand()%800, y = rand()%600;
    this->addPoint(x,y);
}
